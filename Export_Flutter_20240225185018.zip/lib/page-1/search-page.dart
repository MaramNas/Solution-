import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // searchpageUYP (46:657)
        width: double.infinity,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.circular(30*fem),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/search-page-bg.png',
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0x663f526c),
              offset: Offset(0*fem, 40*fem),
              blurRadius: 40*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              // autogroupkjq1M6P (3YUrYNKKbXx936GYmKkjQ1)
              padding: EdgeInsets.fromLTRB(0*fem, 23*fem, 0*fem, 70.65*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // topsystembarGUF (46:711)
                    margin: EdgeInsets.fromLTRB(30*fem, 0*fem, 36*fem, 2*fem),
                    width: double.infinity,
                    height: 17*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // timeC71 (46:712)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 260*fem, 0*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // ellipse1voh (46:713)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 1*fem),
                                width: 4*fem,
                                height: 4*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(2*fem),
                                  color: Color(0x7f313033),
                                ),
                              ),
                              Text(
                                // rBZ (46:714)
                                '12:00',
                                style: SafeGoogleFont (
                                  'Roboto',
                                  fontSize: 14*ffem,
                                  fontWeight: FontWeight.w500,
                                  height: 1.1725*ffem/fem,
                                  color: Color(0xff313033),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // batteryPBV (46:715)
                          margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // vector1X2o (46:716)
                                width: 14*fem,
                                height: 14*fem,
                                child: Image.asset(
                                  'assets/page-1/images/vector-1-t7y.png',
                                  width: 14*fem,
                                  height: 14*fem,
                                ),
                              ),
                              SizedBox(
                                width: 6*fem,
                              ),
                              Container(
                                // ellipse2ET1 (46:717)
                                width: 17*fem,
                                height: 13*fem,
                                child: Image.asset(
                                  'assets/page-1/images/ellipse-2-A9V.png',
                                  width: 17*fem,
                                  height: 13*fem,
                                ),
                              ),
                              SizedBox(
                                width: 6*fem,
                              ),
                              Container(
                                // unionmC3 (46:718)
                                width: 8*fem,
                                height: 13*fem,
                                child: Image.asset(
                                  'assets/page-1/images/union-kf9.png',
                                  width: 8*fem,
                                  height: 13*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // topappbarWQX (46:697)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 17*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(94*fem, 14*fem, 0*fem, 14*fem),
                        width: 480*fem,
                        height: 64*fem,
                        child: Container(
                          // topappbarCo9 (46:698)
                          width: double.infinity,
                          height: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame155Mvw (46:699)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 207*fem, 0*fem),
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // ellipse343VnF (46:700)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 0*fem),
                                      width: 36*fem,
                                      height: 36*fem,
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(18*fem),
                                        border: Border.all(color: Color(0xffffffff)),
                                        image: DecorationImage (
                                          fit: BoxFit.cover,
                                          image: AssetImage (
                                            'assets/page-1/images/ellipse-343-bg-t4P.png',
                                          ),
                                        ),
                                      ),
                                    ),
                                    Text(
                                      // headlinec6B (46:701)
                                      'Hello, Anna',
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 16*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // trailingiconLns (46:702)
                                width: 36*fem,
                                height: 36*fem,
                                child: Image.asset(
                                  'assets/page-1/images/trailing-icon-EBy.png',
                                  width: 36*fem,
                                  height: 36*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // searchbars27 (46:670)
                    margin: EdgeInsets.fromLTRB(19*fem, 0*fem, 21*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // locationyqq (46:672)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 70*fem, 0*fem),
                          padding: EdgeInsets.fromLTRB(23*fem, 0*fem, 19.47*fem, 0*fem),
                          width: double.infinity,
                          height: 42.68*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame1464MV (46:673)
                                margin: EdgeInsets.fromLTRB(0*fem, 11.34*fem, 131*fem, 11.34*fem),
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // iconssearch24pxBBD (46:674)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13.51*fem, 0.51*fem),
                                      width: 17.49*fem,
                                      height: 17.49*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/icons-search24px-iPR.png',
                                        width: 17.49*fem,
                                        height: 17.49*fem,
                                      ),
                                    ),
                                    Center(
                                      // locationUw1 (46:675)
                                      child: Text(
                                        'Location',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.25*ffem/fem,
                                          letterSpacing: 0.32*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // filterCc7 (46:676)
                                width: 44.53*fem,
                                height: 42.68*fem,
                                child: Image.asset(
                                  'assets/page-1/images/filter-R9R.png',
                                  width: 44.53*fem,
                                  height: 42.68*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10*fem,
                        ),
                        Container(
                          // dateX8b (46:683)
                          padding: EdgeInsets.fromLTRB(20*fem, 0*fem, 19.47*fem, 0*fem),
                          width: double.infinity,
                          height: 42.68*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(10*fem),
                          ),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // frame146Eoh (46:684)
                                margin: EdgeInsets.fromLTRB(0*fem, 9.34*fem, 185*fem, 9.34*fem),
                                padding: EdgeInsets.fromLTRB(2*fem, 1*fem, 0*fem, 1*fem),
                                height: double.infinity,
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // calendartodayABZ (46:685)
                                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 7*fem, 0*fem),
                                      width: 20*fem,
                                      height: 22*fem,
                                      child: Image.asset(
                                        'assets/page-1/images/calendartoday.png',
                                        width: 20*fem,
                                        height: 22*fem,
                                      ),
                                    ),
                                    Center(
                                      // july24t7Z (46:687)
                                      child: Text(
                                        '25 July 24  ',
                                        textAlign: TextAlign.center,
                                        style: SafeGoogleFont (
                                          'Poppins',
                                          fontSize: 16*ffem,
                                          fontWeight: FontWeight.w400,
                                          height: 1.25*ffem/fem,
                                          letterSpacing: 0.32*fem,
                                          color: Color(0xff000000),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Opacity(
                                // filterzgP (46:688)
                                opacity: 0,
                                child: Container(
                                  width: 44.53*fem,
                                  height: 42.68*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/filter.png',
                                    width: 44.53*fem,
                                    height: 42.68*fem,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10*fem,
                        ),
                        Container(
                          // continuebuttons6zK (46:695)
                          margin: EdgeInsets.fromLTRB(127*fem, 0*fem, 127*fem, 0*fem),
                          width: double.infinity,
                          height: 44*fem,
                          decoration: BoxDecoration (
                            color: Color(0xffffffff),
                            borderRadius: BorderRadius.circular(20*fem),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // contentpQX (46:658)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
              padding: EdgeInsets.fromLTRB(6.21*fem, 20*fem, 0*fem, 4*fem),
              width: 872*fem,
              decoration: BoxDecoration (
                color: Color(0xffe5e8e4),
                borderRadius: BorderRadius.circular(30*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // image1hjD (46:659)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 11*fem),
                    width: 417.58*fem,
                    height: 209*fem,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(15*fem),
                      child: Image.asset(
                        'assets/page-1/images/image-1.png',
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  Container(
                    // autogroupwkwdDBm (3YUsD6hnYv2Zw4pm3LWKWd)
                    margin: EdgeInsets.fromLTRB(13.79*fem, 0*fem, 0*fem, 26*fem),
                    padding: EdgeInsets.fromLTRB(35*fem, 9*fem, 35*fem, 0*fem),
                    width: 852*fem,
                    height: 128*fem,
                    child: Container(
                      // frame1667nw (46:663)
                      width: 260*fem,
                      height: double.infinity,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            // frame157rkX (46:664)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3.5*fem),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  // saudiarabiao9y (46:665)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20.5*fem),
                                  child: Text(
                                    'Saudi Arabia ',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 14*ffem,
                                      fontWeight: FontWeight.w500,
                                      height: 1.4285714286*ffem/fem,
                                      letterSpacing: 0.1000000015*fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                Text(
                                  // alriyadhcitytx7 (46:666)
                                  'Al Riyadh city  \n',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xff625b71),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            // thewinterseasoninwhichvegetabl (46:667)
                            constraints: BoxConstraints (
                              maxWidth: 260*fem,
                            ),
                            child: Text(
                              'The winter season, in which vegetables are grown, the produce of which is less than a year in quantity... ',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 12*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // readmoreJF9 (46:669)
                    margin: EdgeInsets.fromLTRB(290.79*fem, 0*fem, 0*fem, 35*fem),
                    child: TextButton(
                      onPressed: () {},
                      style: TextButton.styleFrom (
                        padding: EdgeInsets.zero,
                      ),
                      child: RichText(
                        text: TextSpan(
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.5*ffem/fem,
                            color: Color(0xff000000),
                          ),
                          children: [
                            TextSpan(
                              text: ' R',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                            TextSpan(
                              text: 'ead',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                            TextSpan(
                              text: ' ',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                            TextSpan(
                              text: 'More',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.5*ffem/fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    // homeindicatoruXm (46:722)
                    margin: EdgeInsets.fromLTRB(138.79*fem, 0*fem, 0*fem, 0*fem),
                    width: 70*fem,
                    height: 3*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // appbars1qh (46:696)
              margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 0*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 420*fem,
                  height: 127*fem,
                  child: Image.asset(
                    'assets/page-1/images/app-bars-Czj.png',
                    width: 420*fem,
                    height: 127*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}