import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: TextButton(
        // maskgroupMDR (11:56)
        onPressed: () {},
        style: TextButton.styleFrom (
          padding: EdgeInsets.zero,
        ),
        child: Container(
          width: double.infinity,
          height: 932*fem,
          decoration: BoxDecoration (
            borderRadius: BorderRadius.circular(30*fem),
            boxShadow: [
              BoxShadow(
                color: Color(0x3f000000),
                offset: Offset(0*fem, 4*fem),
                blurRadius: 2*fem,
              ),
              BoxShadow(
                color: Color(0x3f000000),
                offset: Offset(0*fem, 4*fem),
                blurRadius: 2*fem,
              ),
            ],
          ),
          child: Container(
            // loginw59 (0:42)
            padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 7*fem),
            width: double.infinity,
            height: double.infinity,
            decoration: BoxDecoration (
              color: Color(0xffe6e8e5),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  // autogroupsouoQzK (3YUjHF5gqRQhBivyCHSouo)
                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 37*fem, 32*fem),
                  padding: EdgeInsets.fromLTRB(123*fem, 761*fem, 0*fem, 0*fem),
                  width: 470*fem,
                  height: 982*fem,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Container(
                        // notificationJK1 (0:44)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 54*fem),
                        width: double.infinity,
                        decoration: BoxDecoration (
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                            BoxShadow(
                              color: Color(0x3f000000),
                              offset: Offset(0*fem, 4*fem),
                              blurRadius: 2*fem,
                            ),
                          ],
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              // cU7 (I0:44;0:116)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 257.16*fem, 0*fem),
                              child: Text(
                                '9:45',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 13*ffem,
                                  fontWeight: FontWeight.w600,
                                  height: 1.1568750235*ffem/fem,
                                  letterSpacing: 0.78*fem,
                                  color: Color(0xff000000),
                                ),
                              ),
                            ),
                            Container(
                              // signal68P (I0:44;0:112)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.29*fem, 0*fem),
                              width: 14.5*fem,
                              height: 16*fem,
                              child: Image.asset(
                                'assets/page-1/images/signal.png',
                                width: 14.5*fem,
                                height: 16*fem,
                              ),
                            ),
                            Container(
                              // wifiChD (I0:44;0:110)
                              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.7*fem, 0*fem),
                              width: 15.68*fem,
                              height: 14*fem,
                              child: Image.asset(
                                'assets/page-1/images/wifi-279.png',
                                width: 15.68*fem,
                                height: 14*fem,
                              ),
                            ),
                            Container(
                              // batterythreequartersXDh (I0:44;0:114)
                              width: 15.68*fem,
                              height: 10*fem,
                              child: Image.asset(
                                'assets/page-1/images/battery-three-quarters-5S7.png',
                                width: 15.68*fem,
                                height: 10*fem,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        // e3R (36:437)
                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 76*fem, 0*fem),
                        width: 209*fem,
                        height: 151*fem,
                        child: Image.asset(
                          'assets/page-1/images/-MyZ.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ],
                  ),
                ),
                Container(
                  // welcomebackx47 (0:45)
                  margin: EdgeInsets.fromLTRB(11*fem, 0*fem, 0*fem, 54*fem),
                  child: Text(
                    'Welcome Back!',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.1568749746*ffem/fem,
                      letterSpacing: 1.08*fem,
                      color: Color(0xbf000000),
                    ),
                  ),
                ),
                Container(
                  // inputFJ7 (0:49)
                  margin: EdgeInsets.fromLTRB(53*fem, 0*fem, 52*fem, 23*fem),
                  padding: EdgeInsets.fromLTRB(30*fem, 14.69*fem, 30*fem, 17.31*fem),
                  width: double.infinity,
                  decoration: BoxDecoration (
                    color: Color(0xffffffff),
                    borderRadius: BorderRadius.circular(22*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Text(
                    'Enter your email',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3718750293*ffem/fem,
                      letterSpacing: 0.78*fem,
                      color: Color(0xb2000000),
                    ),
                  ),
                ),
                Container(
                  // inputTQB (0:50)
                  margin: EdgeInsets.fromLTRB(53*fem, 0*fem, 52*fem, 25*fem),
                  padding: EdgeInsets.fromLTRB(30*fem, 14.69*fem, 30*fem, 17.31*fem),
                  width: double.infinity,
                  decoration: BoxDecoration (
                    color: Color(0xffffffff),
                    borderRadius: BorderRadius.circular(22*fem),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                      BoxShadow(
                        color: Color(0x3f000000),
                        offset: Offset(0*fem, 4*fem),
                        blurRadius: 2*fem,
                      ),
                    ],
                  ),
                  child: Text(
                    'Enter password',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3718750293*ffem/fem,
                      letterSpacing: 0.78*fem,
                      color: Color(0xb2000000),
                    ),
                  ),
                ),
                Container(
                  // forgotpassword5Af (0:46)
                  margin: EdgeInsets.fromLTRB(38*fem, 0*fem, 0*fem, 23*fem),
                  child: Text(
                    'Forgot Password',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1568750654*ffem/fem,
                      letterSpacing: 0.84*fem,
                      color: Color(0xff276014),
                    ),
                  ),
                ),
                Container(
                  // buttonZLj (0:48)
                  margin: EdgeInsets.fromLTRB(53*fem, 0*fem, 51*fem, 30*fem),
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: Container(
                      width: double.infinity,
                      height: 61*fem,
                      decoration: BoxDecoration (
                        color: Color(0xff275f14),
                      ),
                      child: Center(
                        child: Center(
                          child: Text(
                            'Sign In',
                            textAlign: TextAlign.center,
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 18*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.3718750212*ffem/fem,
                              letterSpacing: 1.08*fem,
                              color: Color(0xffffffff),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  // donthaveanaccountsignupnjH (0:47)
                  margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 21*fem),
                  child: TextButton(
                    onPressed: () {},
                    style: TextButton.styleFrom (
                      padding: EdgeInsets.zero,
                    ),
                    child: RichText(
                      textAlign: TextAlign.center,
                      text: TextSpan(
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w400,
                          height: 1.1568750654*ffem/fem,
                          letterSpacing: 0.84*fem,
                          color: Color(0xff000000),
                        ),
                        children: [
                          TextSpan(
                            text: 'Don’t have an account ? ',
                          ),
                          TextSpan(
                            text: 'Sign Up',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w700,
                              height: 1.1568750654*ffem/fem,
                              letterSpacing: 0.84*fem,
                              color: Color(0xff276014),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Container(
                  // UP9 (36:438)
                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 130*fem, 0*fem),
                  width: 296*fem,
                  height: 257*fem,
                  child: Image.asset(
                    'assets/page-1/images/-JJT.png',
                    fit: BoxFit.cover,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
          );
  }
}