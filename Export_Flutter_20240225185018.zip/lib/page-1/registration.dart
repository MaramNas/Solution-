import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // registration9mR (0:92)
        padding: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffe6e8e5),
          borderRadius: BorderRadius.circular(30*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // notificationEXy (0:94)
              margin: EdgeInsets.fromLTRB(56*fem, 0*fem, 29*fem, 56*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // 7bm (I0:94;0:116)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 255.49*fem, 0*fem),
                    child: Text(
                      '9:45',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.1568750235*ffem/fem,
                        letterSpacing: 0.78*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // signalRcT (I0:94;0:112)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.25*fem, 0*fem),
                    width: 14.42*fem,
                    height: 16*fem,
                    child: Image.asset(
                      'assets/page-1/images/signal-FqR.png',
                      width: 14.42*fem,
                      height: 16*fem,
                    ),
                  ),
                  Container(
                    // wifi9YT (I0:94;0:110)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.67*fem, 0*fem),
                    width: 15.59*fem,
                    height: 14*fem,
                    child: Image.asset(
                      'assets/page-1/images/wifi.png',
                      width: 15.59*fem,
                      height: 14*fem,
                    ),
                  ),
                  Container(
                    // batterythreequartersfmh (I0:94;0:114)
                    width: 15.59*fem,
                    height: 10*fem,
                    child: Image.asset(
                      'assets/page-1/images/battery-three-quarters-rTy.png',
                      width: 15.59*fem,
                      height: 10*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // oN7 (36:418)
              margin: EdgeInsets.fromLTRB(3*fem, 0*fem, 0*fem, 21*fem),
              width: 209*fem,
              height: 151*fem,
              child: Image.asset(
                'assets/page-1/images/-Z4j.png',
                fit: BoxFit.cover,
              ),
            ),
            Container(
              // welcometofasilahizs (0:95)
              margin: EdgeInsets.fromLTRB(9*fem, 0*fem, 0*fem, 14*fem),
              child: Text(
                'Welcome to Fasilah',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.1568749746*ffem/fem,
                  letterSpacing: 1.08*fem,
                  color: Color(0xbf000000),
                ),
              ),
            ),
            Container(
              // letsstartyourwonderfuljourneyR (0:96)
              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 34*fem),
              child: Text(
                'Let’s start your wonderful journey',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xbc000000),
                ),
              ),
            ),
            Container(
              // inputvr3 (0:101)
              margin: EdgeInsets.fromLTRB(53*fem, 0*fem, 52*fem, 21*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Text(
                'Enter your full name',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // inputMRZ (0:98)
              margin: EdgeInsets.fromLTRB(55*fem, 0*fem, 50*fem, 21*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Text(
                'Enter your email',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // inputP7M (0:102)
              margin: EdgeInsets.fromLTRB(53*fem, 0*fem, 52*fem, 47*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Text(
                'Enter password',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // buttonRJw (0:97)
              margin: EdgeInsets.fromLTRB(53*fem, 0*fem, 51*fem, 23*fem),
              width: double.infinity,
              height: 62*fem,
              decoration: BoxDecoration (
                color: Color(0xff275f14),
              ),
              child: Center(
                child: Center(
                  child: Text(
                    'Register',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.3718750212*ffem/fem,
                      letterSpacing: 1.08*fem,
                      color: Color(0xffffffff),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // autogroupwmdfgEs (3YUjzZEBb2ZHUVno6AWmdf)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 80.5*fem, 0*fem),
              width: 349.5*fem,
              height: 273*fem,
              child: Stack(
                children: [
                  Positioned(
                    // Cj1 (36:412)
                    left: 0*fem,
                    top: 16*fem,
                    child: Align(
                      child: SizedBox(
                        width: 296*fem,
                        height: 257*fem,
                        child: Image.asset(
                          'assets/page-1/images/-PVZ.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // alreadyhaveanaccountsignin6Jb (0:104)
                    left: 81.5*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 268*fem,
                        height: 17*fem,
                        child: TextButton(
                          onPressed: () {},
                          style: TextButton.styleFrom (
                            padding: EdgeInsets.zero,
                          ),
                          child: RichText(
                            textAlign: TextAlign.center,
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w400,
                                height: 1.1568750654*ffem/fem,
                                letterSpacing: 0.84*fem,
                                color: Color(0xff000000),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Already have an account ? ',
                                ),
                                TextSpan(
                                  text: 'Sign In',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w700,
                                    height: 1.1568750654*ffem/fem,
                                    letterSpacing: 0.84*fem,
                                    color: Color(0xff276014),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}