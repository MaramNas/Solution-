import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // notifcationpage127 (36:444)
        padding: EdgeInsets.fromLTRB(0*fem, 22.5*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.circular(30*fem),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/notifcation-page-bg.png',
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0x663f526c),
              offset: Offset(0*fem, 40*fem),
              blurRadius: 40*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // topsystembareKy (36:465)
              margin: EdgeInsets.fromLTRB(30*fem, 0*fem, 40*fem, 91.5*fem),
              width: double.infinity,
              height: 17*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timeAZD (36:466)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 256*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // ellipse1JQX (36:467)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 1*fem),
                          width: 4*fem,
                          height: 4*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2*fem),
                            color: Color(0x7f313033),
                          ),
                        ),
                        Text(
                          // E3H (36:468)
                          '12:00',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff313033),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // batteryZ5Z (36:469)
                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vector1gvs (36:470)
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-1-pcw.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        SizedBox(
                          width: 6*fem,
                        ),
                        Container(
                          // ellipse2okb (36:471)
                          width: 17*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/ellipse-2.png',
                            width: 17*fem,
                            height: 13*fem,
                          ),
                        ),
                        SizedBox(
                          width: 6*fem,
                        ),
                        Container(
                          // unionvaK (36:472)
                          width: 8*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/union-PBD.png',
                            width: 8*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // trailingicon4gX (46:764)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
              width: 36*fem,
              height: 36*fem,
              child: Image.asset(
                'assets/page-1/images/trailing-icon.png',
                width: 36*fem,
                height: 36*fem,
              ),
            ),
            Container(
              // autogroupyhfbBFM (3YUuqwUnGxxDgeQx4nYhFb)
              margin: EdgeInsets.fromLTRB(10*fem, 0*fem, 20*fem, 161*fem),
              padding: EdgeInsets.fromLTRB(20*fem, 35*fem, 26*fem, 279*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffd9d9d9),
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupgdzdH3V (3YUuxX89hDZ9ZG6DzmgDzd)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 31*fem),
                    padding: EdgeInsets.fromLTRB(8*fem, 26*fem, 8*fem, 25*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(15*fem),
                    ),
                    child: Text(
                      'It\'s tomato planting season in your city',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupiyiu8po (3YUv2rLGT5YeQjFC14iyiu)
                    padding: EdgeInsets.fromLTRB(8*fem, 26*fem, 8*fem, 25*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(15*fem),
                    ),
                    child: Text(
                      'You can start growing dates today',
                      style: SafeGoogleFont (
                        'Roboto',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w500,
                        height: 1.1725*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // appbarsQnK (48:1019)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 10*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 420*fem,
                  height: 127*fem,
                  child: Image.asset(
                    'assets/page-1/images/app-bars-JPq.png',
                    width: 420*fem,
                    height: 127*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}