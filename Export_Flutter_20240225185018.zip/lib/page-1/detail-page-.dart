import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // detailpageuLs (28:388)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffd4ddec),
          borderRadius: BorderRadius.circular(30*fem),
          boxShadow: [
            BoxShadow(
              color: Color(0x3f3f526c),
              offset: Offset(0*fem, 40*fem),
              blurRadius: 40*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogroupyuxvbzP (3YUvqVfDN44vfvbtymYUxV)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 5*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 20*fem, 0*fem, 90.5*fem),
              width: 427*fem,
              decoration: BoxDecoration (
                image: DecorationImage (
                  fit: BoxFit.cover,
                  image: AssetImage (
                    'assets/page-1/images/image-2-bg-iNT.png',
                  ),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // topappbarswu (28:391)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 15*fem, 76.5*fem),
                    width: 412*fem,
                    height: 80*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // topsystembar12X (28:392)
                          left: 30*fem,
                          top: 0*fem,
                          child: Container(
                            width: 369*fem,
                            height: 17*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // time8N3 (28:393)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 265*fem, 0*fem),
                                  height: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // ellipse1Gj9 (28:394)
                                        margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 1*fem),
                                        width: 4*fem,
                                        height: 4*fem,
                                        decoration: BoxDecoration (
                                          borderRadius: BorderRadius.circular(2*fem),
                                          color: Color(0x7fffffff),
                                        ),
                                      ),
                                      Text(
                                        // bWX (28:395)
                                        '12:00',
                                        style: SafeGoogleFont (
                                          'Roboto',
                                          fontSize: 14*ffem,
                                          fontWeight: FontWeight.w500,
                                          height: 1.1725*ffem/fem,
                                          color: Color(0xffffffff),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  // batteryLDD (28:396)
                                  margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                                  height: double.infinity,
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    children: [
                                      Container(
                                        // vector1G6s (28:397)
                                        width: 14*fem,
                                        height: 14*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/vector-1-k87.png',
                                          width: 14*fem,
                                          height: 14*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 6*fem,
                                      ),
                                      Container(
                                        // ellipse2BUj (28:398)
                                        width: 17*fem,
                                        height: 13*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/ellipse-2-VZy.png',
                                          width: 17*fem,
                                          height: 13*fem,
                                        ),
                                      ),
                                      SizedBox(
                                        width: 6*fem,
                                      ),
                                      Container(
                                        // unionhxs (28:399)
                                        width: 8*fem,
                                        height: 13*fem,
                                        child: Image.asset(
                                          'assets/page-1/images/union-RNf.png',
                                          width: 8*fem,
                                          height: 13*fem,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // topappbaredD (28:402)
                          left: 0*fem,
                          top: 16*fem,
                          child: TextButton(
                            onPressed: () {},
                            style: TextButton.styleFrom (
                              padding: EdgeInsets.zero,
                            ),
                            child: Container(
                              padding: EdgeInsets.fromLTRB(20*fem, 24*fem, 2.01*fem, 18*fem),
                              width: 412*fem,
                              height: 64*fem,
                              decoration: BoxDecoration (
                                boxShadow: [
                                  BoxShadow(
                                    color: Color(0x26000000),
                                    offset: Offset(0*fem, 2*fem),
                                    blurRadius: 3*fem,
                                  ),
                                  BoxShadow(
                                    color: Color(0x4c000000),
                                    offset: Offset(0*fem, 1*fem),
                                    blurRadius: 1*fem,
                                  ),
                                ],
                              ),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    // leadingiconJhm (28:403)
                                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 306*fem, 6*fem),
                                    width: 16*fem,
                                    height: 16*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/leading-icon.png',
                                      width: 16*fem,
                                      height: 16*fem,
                                    ),
                                  ),
                                  Container(
                                    // trailingiconRXV (28:405)
                                    margin: EdgeInsets.fromLTRB(0*fem, 1.99*fem, 0*fem, 0*fem),
                                    width: 67.99*fem,
                                    height: 20.01*fem,
                                    child: Image.asset(
                                      'assets/page-1/images/trailing-icon-Xaf.png',
                                      width: 67.99*fem,
                                      height: 20.01*fem,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // winterinriyadhjYB (35:369)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 0*fem),
                    child: Text(
                      'Winter in Riyadh',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 34*ffem,
                        fontWeight: FontWeight.w400,
                        height: 1.5*ffem/fem,
                        color: Color(0xfffffbfe),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // contentShV (28:409)
              padding: EdgeInsets.fromLTRB(34.5*fem, 10*fem, 34.5*fem, 89*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffe5e8e4),
                borderRadius: BorderRadius.circular(30*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // menu8qD (28:410)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 14*fem),
                    padding: EdgeInsets.fromLTRB(21*fem, 16*fem, 0*fem, 21*fem),
                    width: double.infinity,
                    height: 77*fem,
                    child: Container(
                      // menusdX5 (28:411)
                      width: 490*fem,
                      height: double.infinity,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // buttonwXm (28:412)
                            width: 99*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffbdc1bc),
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'Grains ',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.4285714286*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 20*fem,
                          ),
                          Container(
                            // buttonjyR (28:413)
                            width: 99*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'Fruits ',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.4285714286*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xff313033),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 20*fem,
                          ),
                          Container(
                            // buttonpV5 (28:414)
                            width: 99*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'Vegetables ',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.4285714286*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xff313033),
                                  ),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 20*fem,
                          ),
                          Container(
                            // buttontE3 (28:415)
                            width: 133*fem,
                            height: double.infinity,
                            decoration: BoxDecoration (
                              color: Color(0xffffffff),
                              borderRadius: BorderRadius.circular(100*fem),
                            ),
                            child: Center(
                              child: Center(
                                child: Text(
                                  'Community',
                                  textAlign: TextAlign.center,
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w500,
                                    height: 1.4285714286*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xff313033),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    // pictureBD9 (28:416)
                    margin: EdgeInsets.fromLTRB(20.5*fem, 0*fem, 20.5*fem, 29*fem),
                    width: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // image3JoZ (29:222)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 50*fem, 0*fem),
                          width: 134*fem,
                          height: 177*fem,
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(15*fem),
                            child: Image.asset(
                              'assets/page-1/images/image-3.png',
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        Container(
                          // morepicturecZM (28:443)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 4*fem),
                          width: 136*fem,
                          height: 178*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/image-4-bg.png',
                              ),
                            ),
                          ),
                          child: Center(
                            child: Text(
                              '10+',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 17*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.038348815*ffem/fem,
                                color: Color(0xffffffff),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // descriptionH9h (28:446)
                    margin: EdgeInsets.fromLTRB(20*fem, 0*fem, 20*fem, 0*fem),
                    width: double.infinity,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // chestnutsabofaroahD3M (28:447)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 20*fem),
                          child: RichText(
                            text: TextSpan(
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 14*ffem,
                                fontWeight: FontWeight.w500,
                                height: 1.4285714286*ffem/fem,
                                letterSpacing: 0.1000000015*fem,
                                color: Color(0xff000000),
                              ),
                              children: [
                                TextSpan(
                                  text: 'Chestnuts ',
                                ),
                                TextSpan(
                                  text: '(',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.4285714286*ffem/fem,
                                    letterSpacing: 0.1000000015*fem,
                                    color: Color(0xff000000),
                                  ),
                                ),
                                TextSpan(
                                  text: 'Abo Faroah) ',
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          // withtheonsetofwinterpeoplerush (28:448)
                          constraints: BoxConstraints (
                            maxWidth: 321*fem,
                          ),
                          child: Text(
                            'With the onset of winter, people rush to buy “Abu Farwa” or chestnuts, which are the most famous types of nuts, and are often served after being grilled over a fire. They are called the “winter fruit,” as they are considered one of the most favorite winter foods when families and friends gather during warm evenings and road trips.',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 14*ffem,
                              fontWeight: FontWeight.w400,
                              height: 1.5*ffem/fem,
                              color: Color(0x99000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}