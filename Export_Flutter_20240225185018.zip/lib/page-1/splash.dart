import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // splashYxX (0:105)
        padding: EdgeInsets.fromLTRB(0*fem, 17*fem, 0*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xffe6e8e5),
          borderRadius: BorderRadius.circular(30*fem),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // notificationf1Z (0:117)
              margin: EdgeInsets.fromLTRB(37*fem, 0*fem, 54*fem, 85*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                boxShadow: [
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                  BoxShadow(
                    color: Color(0x3f000000),
                    offset: Offset(0*fem, 4*fem),
                    blurRadius: 2*fem,
                  ),
                ],
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // wDy (I0:117;0:116)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 250.49*fem, 4*fem),
                    child: Text(
                      '9:45',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 13*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.1568750235*ffem/fem,
                        letterSpacing: 0.78*fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // signalFVZ (I0:117;0:112)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6.14*fem, 0*fem),
                    width: 14.17*fem,
                    height: 20*fem,
                    child: Image.asset(
                      'assets/page-1/images/signal-5SX.png',
                      width: 14.17*fem,
                      height: 20*fem,
                    ),
                  ),
                  Container(
                    // wifiZm9 (I0:117;0:110)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.57*fem, 0*fem),
                    width: 15.31*fem,
                    height: 17.5*fem,
                    child: Image.asset(
                      'assets/page-1/images/wifi-4uV.png',
                      width: 15.31*fem,
                      height: 17.5*fem,
                    ),
                  ),
                  Container(
                    // batterythreequarterstoR (I0:117;0:114)
                    width: 15.31*fem,
                    height: 12.5*fem,
                    child: Image.asset(
                      'assets/page-1/images/battery-three-quarters.png',
                      width: 15.31*fem,
                      height: 12.5*fem,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupdjx7czK (3YUkRiAwHcMSfBGKtVDJX7)
              margin: EdgeInsets.fromLTRB(75*fem, 0*fem, 75*fem, 30*fem),
              width: double.infinity,
              height: 440*fem,
              child: Stack(
                children: [
                  Positioned(
                    // Ysy (36:417)
                    left: 9*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 271*fem,
                        height: 422*fem,
                        child: Image.asset(
                          'assets/page-1/images/-LBy.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // plantwithusTV9 (0:154)
                    left: 64*fem,
                    top: 329*fem,
                    child: Align(
                      child: SizedBox(
                        width: 131*fem,
                        height: 21*fem,
                        child: Text(
                          'Plant with us',
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 18*ffem,
                            fontWeight: FontWeight.w600,
                            height: 1.1568749746*ffem/fem,
                            letterSpacing: 1.08*fem,
                            color: Color(0xbf000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // everythingyouneedtoknowtoplant (0:155)
                    left: 0*fem,
                    top: 368*fem,
                    child: Align(
                      child: SizedBox(
                        width: 268*fem,
                        height: 72*fem,
                        child: Text(
                          'Everything you need to know to plant your first seed, depending on your location and the terrain surrounding you',
                          textAlign: TextAlign.center,
                          style: SafeGoogleFont (
                            'Poppins',
                            fontSize: 13*ffem,
                            fontWeight: FontWeight.w400,
                            height: 1.3718750293*ffem/fem,
                            letterSpacing: 0.78*fem,
                            color: Color(0xbc000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // frame1nfq (10:60)
                    left: 166*fem,
                    top: 211*fem,
                    child: Container(
                      width: 101*fem,
                      height: 100*fem,
                      decoration: BoxDecoration (
                        boxShadow: [
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                          BoxShadow(
                            color: Color(0x3f000000),
                            offset: Offset(0*fem, 4*fem),
                            blurRadius: 2*fem,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // buttongmD (0:156)
              margin: EdgeInsets.fromLTRB(46*fem, 0*fem, 58*fem, 33*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 62*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff275f14),
                  ),
                  child: Center(
                    child: Center(
                      child: Text(
                        'Get Started',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.3718750212*ffem/fem,
                          letterSpacing: 1.08*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // wBM (36:413)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 134*fem, 0*fem),
              width: 296*fem,
              height: 257*fem,
              child: Image.asset(
                'assets/page-1/images/.png',
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
          );
  }
}