import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // mapjq9 (38:598)
        padding: EdgeInsets.fromLTRB(30*fem, 20*fem, 0*fem, 473*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.circular(30*fem),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/map-bg.png',
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0x663f526c),
              offset: Offset(0*fem, 40*fem),
              blurRadius: 40*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // topsystembarQRV (38:601)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 26*fem, 321*fem),
              width: double.infinity,
              height: 17*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timeLK9 (38:602)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 270*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // ellipse1g87 (38:603)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 1*fem),
                          width: 4*fem,
                          height: 4*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2*fem),
                            color: Color(0x7f313033),
                          ),
                        ),
                        Text(
                          // 1AP (38:604)
                          '12:00',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff313033),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // batteryYRD (38:605)
                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vector1H7u (38:606)
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-1-CJj.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        SizedBox(
                          width: 6*fem,
                        ),
                        Container(
                          // ellipse2buH (38:607)
                          width: 17*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/ellipse-2-MH1.png',
                            width: 17*fem,
                            height: 13*fem,
                          ),
                        ),
                        SizedBox(
                          width: 6*fem,
                        ),
                        Container(
                          // unionvRm (38:608)
                          width: 8*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/union-rij.png',
                            width: 8*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupkshoGVd (3YUvXRLznUZnvLUbehKsho)
              width: 327*fem,
              height: 101*fem,
              child: Stack(
                children: [
                  Positioned(
                    // 1i7 (48:911)
                    left: 14*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 49*fem,
                        height: 46*fem,
                        child: Image.asset(
                          'assets/page-1/images/-STq.png',
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // appbarsKyh (48:934)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 327*fem,
                        height: 101*fem,
                        child: Image.asset(
                          'assets/page-1/images/app-bars.png',
                          width: 327*fem,
                          height: 101*fem,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}