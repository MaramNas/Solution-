import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 430;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // profailepageAa3 (29:233)
        padding: EdgeInsets.fromLTRB(2*fem, 20*fem, 2*fem, 0*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          borderRadius: BorderRadius.circular(30*fem),
          image: DecorationImage (
            fit: BoxFit.cover,
            image: AssetImage (
              'assets/page-1/images/profaile-page-bg.png',
            ),
          ),
          boxShadow: [
            BoxShadow(
              color: Color(0x663f526c),
              offset: Offset(0*fem, 40*fem),
              blurRadius: 40*fem,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // topsystembarpPh (29:287)
              margin: EdgeInsets.fromLTRB(28*fem, 0*fem, 35*fem, 22*fem),
              width: double.infinity,
              height: 17*fem,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // timek2T (29:288)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 259*fem, 0*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // ellipse1H2P (29:289)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 13*fem, 1*fem),
                          width: 4*fem,
                          height: 4*fem,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(2*fem),
                            color: Color(0x7f313033),
                          ),
                        ),
                        Text(
                          // bom (29:290)
                          '12:00',
                          style: SafeGoogleFont (
                            'Roboto',
                            fontSize: 14*ffem,
                            fontWeight: FontWeight.w500,
                            height: 1.1725*ffem/fem,
                            color: Color(0xff313033),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // batterywcj (29:291)
                    margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 0*fem, 2*fem),
                    height: double.infinity,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // vector1UMm (29:292)
                          width: 14*fem,
                          height: 14*fem,
                          child: Image.asset(
                            'assets/page-1/images/vector-1-dqR.png',
                            width: 14*fem,
                            height: 14*fem,
                          ),
                        ),
                        SizedBox(
                          width: 6*fem,
                        ),
                        Container(
                          // ellipse2zL7 (29:293)
                          width: 17*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/ellipse-2-TM9.png',
                            width: 17*fem,
                            height: 13*fem,
                          ),
                        ),
                        SizedBox(
                          width: 6*fem,
                        ),
                        Container(
                          // unionhkK (29:294)
                          width: 8*fem,
                          height: 13*fem,
                          child: Image.asset(
                            'assets/page-1/images/union-KmZ.png',
                            width: 8*fem,
                            height: 13*fem,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // trailingiconST1 (29:278)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 9*fem, 47*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 36*fem,
                  height: 36*fem,
                  child: Image.asset(
                    'assets/page-1/images/trailing-icon-TR1.png',
                    width: 36*fem,
                    height: 36*fem,
                  ),
                ),
              ),
            ),
            Container(
              // autogroupgpgq7p3 (3YUtPZjhp7jheRqwtbgPgq)
              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 9*fem, 81*fem),
              padding: EdgeInsets.fromLTRB(13*fem, 10*fem, 203*fem, 2*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffe5e8e4),
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Container(
                    // ellipse343bz7 (29:276)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 22*fem, 23*fem),
                    width: 116*fem,
                    height: 100*fem,
                    child: Image.asset(
                      'assets/page-1/images/ellipse-343.png',
                      width: 116*fem,
                      height: 100*fem,
                    ),
                  ),
                  Container(
                    // autogroupwidkioq (3YUtX9MQdsipdzs8u7WiDK)
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // headlinefj5 (29:277)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 1*fem),
                          child: Text(
                            'Annaa \n',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 16*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                        Container(
                          // yearsoldarabicnHu (36:562)
                          constraints: BoxConstraints (
                            maxWidth: 51*fem,
                          ),
                          child: Text(
                            '22 years old\nArabic',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 12*ffem,
                              height: 1.5*ffem/fem,
                              color: Color(0xff000000),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // autogroupfpqfJ1M (3YUti9366SvvxVeCkwFPqF)
              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 5*fem, 0*fem),
              padding: EdgeInsets.fromLTRB(5*fem, 0*fem, 5*fem, 23*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffe5e8e4),
                borderRadius: BorderRadius.circular(15*fem),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    // favoritesC6j (35:385)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 19*fem),
                    child: Text(
                      'Favorites ',
                      textAlign: TextAlign.right,
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 16*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.5*ffem/fem,
                        color: Color(0xff000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogrouphjbxJfZ (3YUtsJSVJvc2Dud6JnhJBX)
                    margin: EdgeInsets.fromLTRB(11*fem, 0*fem, 7*fem, 199*fem),
                    width: double.infinity,
                    height: 193*fem,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Container(
                          // autogroupbel5RVH (3YUtyYm5bLkDisX4YbbEL5)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 20*fem, 0*fem),
                          padding: EdgeInsets.fromLTRB(40*fem, 59*fem, 37*fem, 32*fem),
                          width: 226*fem,
                          height: double.infinity,
                          decoration: BoxDecoration (
                            borderRadius: BorderRadius.circular(15*fem),
                            image: DecorationImage (
                              fit: BoxFit.cover,
                              image: AssetImage (
                                'assets/page-1/images/image-2-bg.png',
                              ),
                            ),
                          ),
                          child: Center(
                            // winterinriyadhJJB (28:451)
                            child: SizedBox(
                              child: Container(
                                constraints: BoxConstraints (
                                  maxWidth: 149*fem,
                                ),
                                child: Text(
                                  'Winter in Riyadh',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 34*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.5*ffem/fem,
                                    color: Color(0xfffffbfe),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupxncvc3y (3YUu3dUcVptfo6qYnFxncV)
                          width: 143*fem,
                          height: 186*fem,
                          child: Stack(
                            children: [
                              Positioned(
                                // A5V (35:386)
                                left: 54*fem,
                                top: 68*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 27*fem,
                                    height: 60*fem,
                                    child: Text(
                                      '+',
                                      textAlign: TextAlign.right,
                                      style: SafeGoogleFont (
                                        'Poppins',
                                        fontSize: 40*ffem,
                                        fontWeight: FontWeight.w600,
                                        height: 1.5*ffem/fem,
                                        color: Color(0xff000000),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              Positioned(
                                // rectangle840GPR (35:388)
                                left: 0*fem,
                                top: 0*fem,
                                child: Align(
                                  child: SizedBox(
                                    width: 143*fem,
                                    height: 186*fem,
                                    child: Container(
                                      decoration: BoxDecoration (
                                        borderRadius: BorderRadius.circular(15*fem),
                                        border: Border.all(color: Color(0xff000000)),
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // homeindicatoraQ7 (29:298)
                    margin: EdgeInsets.fromLTRB(134*fem, 0*fem, 203*fem, 0*fem),
                    width: double.infinity,
                    height: 3*fem,
                    decoration: BoxDecoration (
                      borderRadius: BorderRadius.circular(100*fem),
                      color: Color(0xff000000),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // appbarsK6o (48:999)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 6*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 420*fem,
                  height: 127*fem,
                  child: Image.asset(
                    'assets/page-1/images/app-bars-5LT.png',
                    width: 420*fem,
                    height: 127*fem,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}