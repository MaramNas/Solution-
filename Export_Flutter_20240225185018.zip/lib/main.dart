import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';
import 'package:myapp/page-1/presonal-page.dart';
// import 'package:myapp/page-1/dashboard.dart';
// import 'package:myapp/page-1/rectangle-35.dart';
// import 'package:myapp/page-1/mask-group.dart';
// import 'package:myapp/page-1/registration.dart';
// import 'package:myapp/page-1/splash.dart';
// import 'package:myapp/page-1/option1.dart';
// import 'package:myapp/page-1/home-items-profile-us.dart';
// import 'package:myapp/page-1/iconse-.dart';
// import 'package:myapp/page-1/menu.dart';
// import 'package:myapp/page-1/menu-NXh.dart';
// import 'package:myapp/page-1/icons2.dart';
// import 'package:myapp/page-1/menue2.dart';
// import 'package:myapp/page-1/home-page1-.dart';
// import 'package:myapp/page-1/search-page.dart';
// import 'package:myapp/page-1/profaile-page.dart';
// import 'package:myapp/page-1/notifcation-page.dart';
// import 'package:myapp/page-1/top-app-bar.dart';
// import 'package:myapp/page-1/map.dart';
// import 'package:myapp/page-1/top-app-bar-xkF.dart';
// import 'package:myapp/page-1/detail-page-.dart';
// import 'package:myapp/page-1/.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
	@override
	Widget build(BuildContext context) {
	return MaterialApp(
		title: 'Flutter',
		debugShowCheckedModeBanner: false,
		scrollBehavior: MyCustomScrollBehavior(),
		theme: ThemeData(
		primarySwatch: Colors.blue,
		),
		home: Scaffold(
		body: SingleChildScrollView(
			child: Scene(),
		),
		),
	);
	}
}
